- TP1 es el binario ejecutable y TP1.cpp donde se ubica el main

- Los experimentos fueron generados como se indica en la parte de experimentacion del informe

- Cuando se uso alguna funcion generadora random, la semilla utilizada fue 8

- Todos los casos de test fueron generados dentro de diversas mains que fueron borradas, entendemos ahora en retrospectiva que no fue la opcion mas prolija, pero sirvio igual. Dejamos una comentada en TP1.cpp por si les interesa.

- Los archivos csv son los resultados con los que graficamos las imagenes del informe.

- En las carpetas BT, FB, MitM, PD y General dentro de ../Experimentacion/nuestra/ se encuentran archivos .py que usamos para generar los graficos, no hay uno por grafico, sino que usamos uno por algoritmo y fuimos comentando las partes que no nos servian y cambiando los archivos que leia.